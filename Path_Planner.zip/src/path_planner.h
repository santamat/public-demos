#ifndef PATH_PLANNER_H
#define PATH_PLANNER_H

#include <vector>
using namespace std;

// Car Sensing return type
typedef enum {
	NO_CARS,
	TOO_CLOSE_BACK,
	TOO_CLOSE_AHEAD,
	TOO_CLOSE_BACK_AND_AHEAD
} t_CarSense;

// Car State for the Behavior Planner
typedef enum {
	LK,
	PLCL,
	PLCR,
	LCL,
	LCR
} t_CarState;

// Function used to sense cars around the ego car. 
// Sensing is made in the specified lane, with the specified back distance and front distance.
t_CarSense SenseCars(int lane, double car_s, double prev_size, vector<vector<double>> sensor_fusion, double dist_back, double dist_ahead);

#endif
